/**
 * Plugin for electron build
 */
Draw.loadPlugin(function(ui)
{
	ui.hideFooter();
});